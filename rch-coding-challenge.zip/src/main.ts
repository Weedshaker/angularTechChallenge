import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { LibExpandablePanel } from './expandable-panel/expandable-panel.component';

@Component({
  selector: 'app-root',
  imports: [LibExpandablePanel],
  template: `
    <lib-expandable-panel />
  `,
})
export class App {}

bootstrapApplication(App);
